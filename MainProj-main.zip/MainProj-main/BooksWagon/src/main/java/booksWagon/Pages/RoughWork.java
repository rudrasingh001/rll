package booksWagon.Pages;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import booksWagon.Utils.ExcelUtils;

public class RoughWork {
	
	
	public static void main(String[]args) throws IOException {
//		
//		WebDriver driver = new ChromeDriver();
//	    driver.manage().window().maximize();
//        driver.get("https://www.bookswagon.com/login");
//        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
//        String username = "6393772559";
//	    String password = "123456789@Abc";
	    String excelPath = "C:\\Users\\shaurya.singh2\\eclipse-workspace\\BooksWagon\\src\\test\\resources\\TestingData\\TestData.xlsx";
	    String sheetName = "Address";
//
//        driver.findElement(By.id("ctl00_phBody_SignIn_txtEmail")).sendKeys(username);
//        driver.findElement(By.id("ctl00_phBody_SignIn_txtPassword")).sendKeys(password);
//        driver.findElement(By.id("ctl00_phBody_SignIn_btnLogin")).click();
//
//	    // Locators
//	    By myAddressSection = By.xpath("//a[@href='myaddress.aspx']");
//	    By addNewAddressBtn = By.xpath("//a[@href='addaddress.aspx']");
//	    By editAddressBtn = By.xpath("//a[@href=\"addaddress.aspx?aid=MjE4NzY3\"]");  //need to give the address which we want to edit
//	    
//	    By country = By.id("ctl00_phBody_ShippingAddress_ddlCountry");
//	    By state = By.id("ctl00_phBody_ShippingAddress_ddlState");
//	    By city  = By.id("ctl00_phBody_ShippingAddress_ddlCities");
//	    
//	    driver.findElement(myAddressSection).click();
//	    driver.findElement(addNewAddressBtn).click();
	    // Address form fields
	    String name = ExcelUtils.getCellData(excelPath, sheetName, 1, 0);
        String company = ExcelUtils.getCellData(excelPath, sheetName, 1, 1);
        String street = ExcelUtils.getCellData(excelPath, sheetName, 1, 2);
        String landmarkVal = ExcelUtils.getCellData(excelPath, sheetName, 1, 3);
        String countryVal = ExcelUtils.getCellData(excelPath, sheetName, 1, 4);
        String stateVal = ExcelUtils.getCellData(excelPath, sheetName, 1, 5);
        String cityVal = ExcelUtils.getCellData(excelPath, sheetName, 1, 6);
        String pin = ExcelUtils.getCellData(excelPath, sheetName, 1, 7);
        String mobileVal = ExcelUtils.getCellData(excelPath, sheetName, 1, 8);
        String phoneVal = ExcelUtils.getCellData(excelPath, sheetName, 1, 9);
        
//        driver.findElement(By.id("ctl00_phBody_ShippingAddress_txtRecipientName")).sendKeys(name);
//        driver.findElement(By.id("ctl00_phBody_ShippingAddress_txtCompanyName")).sendKeys(company);
//
//        driver.findElement(By.id("ctl00_phBody_ShippingAddress_txtAddress")).sendKeys(street);
//        driver.findElement(By.id("ctl00_phBody_ShippingAddress_txtLandmark")).sendKeys(landmarkVal);
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
//        WebElement countryName = driver.findElement(country);
//        Select slct1 = new Select(countryName);
//        slct1.selectByVisibleText(countryVal);
//        
//        wait.until(ExpectedConditions.elementToBeClickable(state));
//        WebElement stateName = driver.findElement(state);
//        Select slct2 = new Select(stateName);
//        slct2.selectByVisibleText(stateVal);
//        
//        wait.until(ExpectedConditions.elementToBeClickable(city));
//        WebElement cityName = driver.findElement(city);
//        Select slct3 = new Select(cityName);
//        slct3.selectByVisibleText(cityVal);

//        driver.findElement(By.id("ctl00_phBody_ShippingAddress_txtPincode")).clear();
//        driver.findElement(By.id("ctl00_phBody_ShippingAddress_txtPincode")).sendKeys(pin);

//        driver.findElement(By.id("ctl00_phBody_ShippingAddress_txtMobile")).clear();
//        driver.findElement(By.id("ctl00_phBody_ShippingAddress_txtMobile")).sendKeys(mobileVal);
//
//        driver.findElement(By.id("ctl00_phBody_ShippingAddress_txtPhone")).clear();
//        driver.findElement(By.id("ctl00_phBody_ShippingAddress_txtPhone")).sendKeys(phoneVal);
		System.out.println(pin.toString());
		System.out.println(phoneVal.toString());
		System.out.println(mobileVal.toString());
	}

}
