package booksWagon.Pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddressPage {

    WebDriver driver;
    WebDriverWait wait;

    // Locators
    By myAddressSection = By.xpath("//a[@href='myaddress.aspx']");
    By addNewAddressBtn = By.xpath("//a[@href='addaddress.aspx']");
    By editAddressBtn = By.xpath("//a[@href=\"addaddress.aspx?aid=MjE4NzY3\"]");  //need to give the address which we want to edit

    // Address form fields
    By fullName  = By.id("ctl00_phBody_ShippingAddress_txtRecipientName");
    By companyName = By.id("ctl00_phBody_ShippingAddress_txtCompanyName");
    By streetAddress = By.id("ctl00_phBody_ShippingAddress_txtAddress");
    By landmark  = By.id("ctl00_phBody_ShippingAddress_txtLandmark");
    By country = By.id("ctl00_phBody_ShippingAddress_ddlCountry");
    By state = By.id("ctl00_phBody_ShippingAddress_ddlState");
    By city  = By.id("ctl00_phBody_ShippingAddress_ddlCities");
    By pinCode = By.id("ctl00_phBody_ShippingAddress_txtPincode");
    By mobile = By.id("ctl00_phBody_ShippingAddress_txtMobile");
    By phone = By.id("ctl00_phBody_ShippingAddress_txtPhone");
    By defaultAdd = By.id("ctl00_phBody_ShippingAddress_chkDefaultAdd");
    By updateBtn = By.id("ctl00_phBody_ShippingAddress_imgSubmit");


    public AddressPage(WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    public void navigateToMyAddressSection() {
        driver.findElement(myAddressSection).click();
    }

    public void clickAddNewAddress() {
        driver.findElement(addNewAddressBtn).click();
    }

    public void clickEditAddress() {
        driver.findElement(editAddressBtn).click();
    }
    

    public void fillAddressForm(String name, String cName, String sAddress, String landmrk,
                                String nation, String stateNative, String nativeCity, String nativePINCode, String mobileNo, String phoneno) {
    	
    	driver.findElement(By.id("ctl00_phBody_ShippingAddress_txtRecipientName")).clear();
        driver.findElement(By.id("ctl00_phBody_ShippingAddress_txtRecipientName")).sendKeys(name);
        
        driver.findElement(By.id("ctl00_phBody_ShippingAddress_txtCompanyName")).clear();
        driver.findElement(By.id("ctl00_phBody_ShippingAddress_txtCompanyName")).sendKeys(cName);
        
        driver.findElement(By.id("ctl00_phBody_ShippingAddress_txtAddress")).clear();
        driver.findElement(By.id("ctl00_phBody_ShippingAddress_txtAddress")).sendKeys(sAddress);
        
        driver.findElement(By.id("ctl00_phBody_ShippingAddress_txtLandmark")).clear();
        driver.findElement(By.id("ctl00_phBody_ShippingAddress_txtLandmark")).sendKeys(landmrk);
        
        wait.until(ExpectedConditions.elementToBeClickable(country));
        WebElement countryName = driver.findElement(country);
        Select slct1 = new Select(countryName);
        slct1.selectByVisibleText(nation);
        
        wait.until(ExpectedConditions.elementToBeClickable(state));
        WebElement stateName = driver.findElement(state);
        Select slct2 = new Select(stateName);
        slct2.selectByVisibleText(stateNative);
        
        wait.until(ExpectedConditions.elementToBeClickable(city));
        WebElement cityName = driver.findElement(city);
        Select slct3 = new Select(cityName);
        slct3.selectByVisibleText(nativeCity);
        
        driver.findElement(pinCode).clear();
        driver.findElement(pinCode).sendKeys(nativePINCode);

        driver.findElement(mobile).clear();
        driver.findElement(mobile).sendKeys(mobileNo);

        driver.findElement(phone).clear();
        driver.findElement(phone).sendKeys(phoneno);

    }

    public void clickUpdate() {
        driver.findElement(updateBtn).click();
    }

    
}
