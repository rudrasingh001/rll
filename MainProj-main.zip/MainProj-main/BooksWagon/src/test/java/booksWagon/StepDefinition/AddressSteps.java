package booksWagon.StepDefinition;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import booksWagon.Pages.AddressPage;
import booksWagon.Utils.ExcelUtils;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AddressSteps {

    WebDriver driver;
    AddressPage addressPage;

    String excelPath = "C:\\Users\\shaurya.singh2\\eclipse-workspace\\BooksWagon\\src\\test\\resources\\TestingData\\TestData.xlsx";
    String sheetName = "Sheet1";

    String username = "6393772559";
    String password = "123456789@Abc";

    @Given("user is logging in and navigating to my address section")
    public void user_is_logging_in_and_navigating_to_my_address_section() throws InterruptedException {
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.bookswagon.com/login");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

        driver.findElement(By.id("ctl00_phBody_SignIn_txtEmail")).sendKeys(username);
        driver.findElement(By.id("ctl00_phBody_SignIn_txtPassword")).sendKeys(password);
        driver.findElement(By.id("ctl00_phBody_SignIn_btnLogin")).click();

        addressPage = new AddressPage(driver);
        addressPage.navigateToMyAddressSection();
    }

    @And("user has add new address option")
    public void user_has_add_new_address_option() {
        System.out.println("adding the address");
    }

    @When("user is clicking add option and enters the details in fields available in add address section and clicks update")
    public void user_is_clicking_add_option_and_enters_the_details_in_fields_available_in_add_address_section_and_clicks_update() throws IOException, InterruptedException {
    	
			int rowCount = ExcelUtils.getRowCount(excelPath, sheetName);

	        for (int i = 1; i < rowCount; i++) {
	        	try {
	        		addressPage.clickAddNewAddress();
		        	
		        	String name = ExcelUtils.getCellData(excelPath, sheetName, i, 0);
		            String company = ExcelUtils.getCellData(excelPath, sheetName, i, 1);
		            String street = ExcelUtils.getCellData(excelPath, sheetName, i, 2);
		            String landmark = ExcelUtils.getCellData(excelPath, sheetName, i, 3);
		            String country = ExcelUtils.getCellData(excelPath, sheetName, i, 4);
		            String state = ExcelUtils.getCellData(excelPath, sheetName, i, 5);
		            String city = ExcelUtils.getCellData(excelPath, sheetName, i, 6);
		            String pin = ExcelUtils.getCellData(excelPath, sheetName, i, 7);
		            String mobile = ExcelUtils.getCellData(excelPath, sheetName, i, 8);
		            String phone = ExcelUtils.getCellData(excelPath, sheetName, i, 9);

		        	
		                
		            addressPage.fillAddressForm(name, company, street, landmark, country, state, city, pin, mobile, phone); 
		            Thread.sleep(2500);
		            addressPage.clickUpdate();
		            ExcelUtils.setCellData(excelPath, sheetName, i, 11, "Passed");
	        	}catch(Exception e) {
	        		System.out.println("Error Found");
	        		ExcelUtils.setCellData(excelPath, sheetName, i, 11, "Failed");	        	}
	        	
	        }
            
        
    }

    @Then("user is able to add address in my address section")
    public void user_is_able_to_add_address() { 
    	
        driver.quit();
    }

//    @And("user is clicking on edit address option of a saved address")
//    public void user_is_clicking_on_edit_address_option() {
//        System.out.println("Inside Step - editing");
//    }

//    @When("user patches the data to old address and click update")
//    public void user_updates_existing_address() throws IOException {
//       System.out.println("Inside step - Patching with old Data");
//    }

//    @Then("user is able to update the exisiting address")
//    public void user_is_able_to_update_address() {
//        System.out.println("Successfully updating with the existing data.");
//    }
}
