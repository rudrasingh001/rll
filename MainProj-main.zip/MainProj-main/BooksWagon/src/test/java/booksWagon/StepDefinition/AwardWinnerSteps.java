package booksWagon.StepDefinition;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import booksWagon.Pages.AwardWinnersPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AwardWinnerSteps {
    WebDriver driver;
    AwardWinnersPage p;

    String username = "6393772559";
    String password = "123456789@Abc";

    @Given("user is on homepage and navigating to Award Winners section")
    public void user_is_on_homepage_and_navigating_to_award_winners_section() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.bookswagon.com/login");

        p = new AwardWinnersPage(driver);
        p.navigatingToAwardWinners(username, password);
    }

    @When("user is selecting the option sort by Low to High of Price")
    public void user_is_selecting_the_option_sort_by_low_to_high_of_price() {
        p.sortingLowToHigh();
    }

    @Then("Books are sorted in Low to High of Price")
    public void books_are_sorted_in_low_to_high_of_price() {
        List<Integer> actList = p.checkingSortingByPrice();
        Assert.assertTrue(p.isSortedAscending(actList), "Books are NOT sorted Low to High by price!");
        driver.quit();
    }

    @When("user is selecting the option sort by High To Low of Price")
    public void user_is_selecting_the_option_sort_by_high_to_low_of_price() {
        p.sortingHighToLow();
    }

    @Then("Books are sorted in High To Low of Price")
    public void books_are_sorted_in_high_to_low_of_price() {
        List<Integer> actList = p.checkingSortingByPrice();
        Assert.assertTrue(p.isSortedDescending(actList), "Books are NOT sorted High to Low by price!");
        driver.quit();
    }

    @When("user is selecting the option sort by Discount")
    public void user_is_selecting_the_option_sort_by_discount() {
        p.sortingByDiscount();
    }

    @Then("Books are sorted in High To Low of discount price")
    public void books_are_sorted_in_high_to_low_of_discount_price() {
        List<Integer> actList = p.checkingSortingByDiscount();
        Assert.assertTrue(p.isSortedDescending(actList), "Books are NOT sorted High to Low by discount!");
        driver.quit();
    }
}
